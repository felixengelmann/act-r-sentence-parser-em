
.onLoad <- function (lib, pkg)   {
	library.dynam("em2", pkg, lib)
}
